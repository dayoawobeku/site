import { redirect } from 'next/navigation';

async function SearchRoot({ searchParams }: {searchParams: any}) {
  redirect(`/search/${searchParams.q ? searchParams.q : '404'}`);
}

export default SearchRoot